# Friends Racing World

3D arcade racing game starter project with online rooms (up to 28 players), browser play, and Windows EXE packaging.

## Requirements
- Node.js 20 or newer (Node 22 LTS recommended)
- npm
- For Windows EXE builds: Windows 10/11

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:5173. The Node/Socket.IO server listens on port 3000; Vite proxies Socket.IO requests during development. For the simplest local multiplayer test, open the production server after building:
```bash
npm run build
npm start
```
Then open http://localhost:3000 in multiple browser tabs.

## Deploy online (Render)
1. Upload the contents of this project folder to a GitHub repository (do not upload the ZIP inside another ZIP).
2. Create a Render **Web Service** connected to that repository.
3. Runtime: Node.
4. Build Command: `npm install && npm run build`
5. Start Command: `npm start`
6. Set Node version to 22 LTS if your dashboard offers a version setting.
7. After deploy, open the Render URL. Multiple users can join the same room code.

The server uses a single in-memory room store. Rooms are cleared when the service restarts or sleeps. For a larger production game, add persistent room coordination (for example Redis) and server-authoritative movement validation.

## Build Windows EXE
On a Windows computer:
```bash
npm install
npm run dist:win
```
The installer and portable EXE are created in `release/`. The EXE can connect to your deployed game server by setting `VITE_GAME_SERVER_URL` at build time. Example in PowerShell: `$env:VITE_GAME_SERVER_URL='https://YOUR-GAME.onrender.com'; npm run dist:win`. Leave it unset only for local testing on the same computer. All distributed EXEs must use the same public server URL to race together.

## Current gameplay
- 3D track and car rendering
- Keyboard and touch steering
- Local practice mode
- Online room creation and joining
- Room list updates and up to 28 player slots
- Ready state and host-start countdown
- Remote car position synchronization

## Important limitations in this first build
This is a playable foundation, not a finished commercial racing simulator. The current prototype uses simplified arcade driving and client-reported position updates. Lap timing, robust collision handling, anti-cheat, matchmaking, persistent leaderboards, and secure server-authoritative physics are future upgrades. The multiplayer desktop build currently starts a local server; configure a public server endpoint before distributing EXEs for cross-device online play.
