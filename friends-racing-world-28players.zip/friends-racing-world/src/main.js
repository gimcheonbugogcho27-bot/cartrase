import * as THREE from 'three';
import { io } from 'socket.io-client';
import './style.css';

const app = document.querySelector('#app');
app.innerHTML = `
  <div class="shell">
    <header class="topbar">
      <div class="brand"><span class="brand-mark">FR</span><span>FRIENDS <b>RACING WORLD</b></span></div>
      <div class="top-status"><span class="live-dot"></span><span id="connectionText">서버 연결 준비 중</span></div>
    </header>
    <main class="layout">
      <section class="game-panel">
        <div class="scene-wrap">
          <div id="scene"></div>
          <div class="scene-vignette"></div>
          <div class="track-label"><span class="tiny-tag">TRACK 01</span><b>SUNSET CIRCUIT</b><small>초보자 추천 · 3 LAPS</small></div>
          <div id="countdown" class="countdown hidden">3</div>
          <div id="hud" class="hud hidden">
            <div class="hud-card"><small>LAP</small><b id="lapText">1 / 3</b></div>
            <div class="hud-card"><small>POSITION</small><b id="positionText">1ST</b></div>
            <div class="hud-card speed"><small>SPEED</small><b><span id="speedText">0</span><i> KM/H</i></b></div>
          </div>
          <div class="scene-bottom"><span>WASD / 방향키로 운전</span><span>SPACE 드리프트 · SHIFT 부스트</span></div>
        </div>
        <div class="below-scene">
          <div><span class="eyebrow">RACE CONTROL</span><h2>트랙에 올라갈 준비가 됐나요?</h2><p>연습 주행은 혼자서도 바로 시작할 수 있어요.</p></div>
          <div class="control-hint"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd><span>운전</span></div>
        </div>
      </section>
      <aside class="side-panel">
        <section class="side-section profile">
          <div class="section-heading"><div><span class="eyebrow">YOUR DRIVER</span><h2>레이서 설정</h2></div><span class="avatar">🏎️</span></div>
          <label class="field-label" for="playerName">닉네임</label>
          <input id="playerName" maxlength="12" value="레이서" placeholder="닉네임 입력" />
          <label class="field-label">자동차 색상</label>
          <div class="colors">
            <button class="color active" data-color="#ff4d5e" style="--car:#ff4d5e" aria-label="빨강"></button>
            <button class="color" data-color="#32c7ff" style="--car:#32c7ff" aria-label="파랑"></button>
            <button class="color" data-color="#ffd34e" style="--car:#ffd34e" aria-label="노랑"></button>
            <button class="color" data-color="#8b6cff" style="--car:#8b6cff" aria-label="보라"></button>
            <button class="color" data-color="#45d69a" style="--car:#45d69a" aria-label="초록"></button>
            <button class="color" data-color="#f4f6fb" style="--car:#f4f6fb" aria-label="흰색"></button>
          </div>
        </section>
        <section class="side-section room-section">
          <div class="section-heading"><div><span class="eyebrow">MULTIPLAYER</span><h2>온라인 레이스</h2></div><span class="capacity">0 / 28</span></div>
          <button id="createRoom" class="primary-btn"><span>＋</span> 레이싱 방 만들기</button>
          <div class="join-row"><input id="roomCode" maxlength="5" placeholder="초대 코드 5자리" /><button id="joinRoom" class="secondary-btn">참가</button></div>
          <div id="roomInfo" class="room-info hidden">
            <div class="room-code-line"><span>방 초대 코드</span><button id="copyCode" class="copy-btn">복사</button></div>
            <strong id="roomCodeText">-----</strong>
            <div id="playerList" class="player-list"></div>
            <div class="room-actions"><button id="readyBtn" class="secondary-btn">준비 완료</button><button id="startRace" class="primary-btn">경기 시작</button></div>
          </div>
          <div id="roomMessage" class="room-message">방을 만들거나 친구의 초대 코드를 입력하세요.</div>
        </section>
        <section class="side-section practice-section">
          <div class="section-heading"><div><span class="eyebrow">QUICK PLAY</span><h2>바로 플레이</h2></div></div>
          <button id="practiceBtn" class="practice-btn"><span class="play-icon">▶</span><span><b>혼자 연습하기</b><small>혼자서 트랙을 달려보세요</small></span><span class="arrow">→</span></button>
          <button id="leaveBtn" class="text-btn hidden">방 나가기</button>
        </section>
        <section class="side-section leaderboard">
          <div class="section-heading"><div><span class="eyebrow">RACE INFO</span><h2>레이스 정보</h2></div></div>
          <div class="info-row"><span>현재 트랙</span><b>선셋 서킷</b></div>
          <div class="info-row"><span>최대 참가 인원</span><b>28명</b></div>
          <div class="info-row"><span>완주 랩</span><b>3바퀴</b></div>
        </section>
        <footer>FRIENDS RACING WORLD <span>v1.0.0</span></footer>
      </aside>
    </main>
    <div id="toast" class="toast"></div>
    <div class="mobile-controls"><button data-key="ArrowLeft">◀</button><button data-key="ArrowUp">▲</button><button data-key="ArrowDown">▼</button><button data-key="ArrowRight">▶</button></div>
  </div>
`;

const $ = id => document.getElementById(id);
const toast = message => {
  $('toast').textContent = message;
  $('toast').classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $('toast').classList.remove('show'), 2600);
};
const serverUrl = import.meta.env.VITE_GAME_SERVER_URL || undefined;
const socket = io(serverUrl, { autoConnect: true, reconnection: true });
let connected = false, roomCode = null, isHost = false, isReady = false;
let roomPlayers = [], raceMode = 'idle', countdownTimer = null;
let selectedColor = 0xff4d5e;
const colorValue = hex => parseInt(hex.replace('#',''), 16);
socket.on('connect', () => { connected = true; $('connectionText').textContent = '온라인 서버 연결됨'; });
socket.on('disconnect', () => { connected = false; $('connectionText').textContent = '서버 연결 끊김 · 재연결 중'; });
socket.on('connect_error', () => { $('connectionText').textContent = '서버 연결 대기 중'; });
socket.on('room:update', data => {
  roomCode = data.code; roomPlayers = data.players; isHost = data.hostId === socket.id;
  // Host identity is supplied separately on room creation/join; preserve it.
  renderRoom(data);
});
socket.on('players:states', states => states.forEach(s => game.updateRemote(s)));
socket.on('race:countdown', ({seconds}) => startCountdown(seconds));
socket.on('race:finished', () => { raceMode = 'finished'; $('roomMessage').textContent = '🏁 모든 레이서가 결승선을 통과했습니다!'; });
function renderRoom(data) {
  $('roomInfo').classList.remove('hidden');
  $('roomCodeText').textContent = data.code;
  $('roomCode').value = data.code;
  $('roomMessage').textContent = data.state === 'racing' ? '레이스 진행 중!' : '친구들이 입장하기를 기다리고 있어요.';
  document.querySelector('.capacity').textContent = `${data.players.length} / 28`;
  $('playerList').innerHTML = data.players.map((p,i) => `<div class="player-row"><span class="player-dot" style="--car:#${Number(p.color).toString(16).padStart(6,'0')}"></span><span>${escapeHtml(p.name)} ${p.id === socket.id ? '<em>(나)</em>' : ''}</span><small>${p.ready ? '준비 완료' : '대기 중'}</small></div>`).join('');
  $('startRace').classList.toggle('hidden', !isHost);
  $('readyBtn').classList.toggle('hidden', isHost || data.state !== 'waiting');
  $('readyBtn').textContent = isReady ? '준비 취소' : '준비 완료';
  $('startRace').disabled = data.players.length < 1;
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

$('createRoom').onclick = () => {
  if (!connected) return toast('온라인 서버에 연결 중입니다. 잠시 후 다시 시도하세요.');
  socket.emit('room:create', { name: $('playerName').value, color: selectedColor }, result => {
    if (!result.ok) return toast(result.error);
    roomCode = result.code; isHost = true; isReady = true;
    toast(`방이 만들어졌어요! 초대 코드: ${result.code}`);
  });
};
$('joinRoom').onclick = () => {
  if (!connected) return toast('온라인 서버에 연결되지 않았습니다.');
  const code = $('roomCode').value.trim().toUpperCase();
  if (code.length !== 5) return toast('초대 코드 5자리를 입력하세요.');
  socket.emit('room:join', { code, name: $('playerName').value, color: selectedColor }, result => {
    if (!result.ok) return toast(result.error);
    roomCode = result.code; isHost = false; isReady = false;
    toast('레이싱 방에 참가했습니다!');
  });
};
$('readyBtn').onclick = () => {
  isReady = !isReady;
  socket.emit('player:ready', isReady);
  $('readyBtn').textContent = isReady ? '준비 취소' : '준비 완료';
};
$('startRace').onclick = () => {
  if (!isHost) return;
  socket.emit('race:start');
};
$('copyCode').onclick = async () => {
  try { await navigator.clipboard.writeText(roomCode || ''); toast('초대 코드를 복사했습니다!'); }
  catch { toast(`초대 코드: ${roomCode}`); }
};
$('leaveBtn').onclick = () => { socket.disconnect(); socket.connect(); roomCode = null; $('roomInfo').classList.add('hidden'); $('leaveBtn').classList.add('hidden'); toast('방에서 나왔습니다.'); };
$('practiceBtn').onclick = () => {
  raceMode = 'practice'; game.start(true); $('hud').classList.remove('hidden');
  $('roomMessage').textContent = '연습 주행 중입니다. ESC를 눌러 메뉴로 돌아오세요.';
  toast('연습 주행을 시작합니다!');
};
document.querySelectorAll('.color').forEach(btn => btn.onclick = () => {
  document.querySelectorAll('.color').forEach(b => b.classList.remove('active'));
  btn.classList.add('active'); selectedColor = colorValue(btn.dataset.color); game.setPlayerColor(selectedColor);
});
function startCountdown(seconds) {
  $('countdown').classList.remove('hidden');
  let n = seconds;
  $('countdown').textContent = n;
  clearInterval(countdownTimer);
  countdownTimer = setInterval(() => {
    n--;
    if (n <= 0) {
      clearInterval(countdownTimer);
      $('countdown').textContent = 'GO!';
      setTimeout(() => $('countdown').classList.add('hidden'), 700);
      raceMode = 'online'; game.start(false); $('hud').classList.remove('hidden');
      $('leaveBtn').classList.remove('hidden');
    } else $('countdown').textContent = n;
  }, 1000);
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && raceMode !== 'idle') {
    raceMode = 'idle'; game.stop(); $('hud').classList.add('hidden'); toast('메뉴로 돌아왔습니다.');
  }
});
document.querySelectorAll('.mobile-controls button').forEach(btn => {
  const key = btn.dataset.key;
  btn.addEventListener('pointerdown', e => { e.preventDefault(); game.keys.add(key); });
  ['pointerup','pointerleave','pointercancel'].forEach(ev => btn.addEventListener(ev, () => game.keys.delete(key)));
});

class RacingGame {
  constructor() {
    this.container = $('scene');
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x9ac8e4);
    this.scene.fog = new THREE.Fog(0x9ac8e4, 65, 190);
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 500);
    this.camera.position.set(0, 13, 22);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.container.appendChild(this.renderer.domElement);
    this.clock = new THREE.Clock();
    this.keys = new Set();
    this.running = false;
    this.speed = 0; this.rotation = 0; this.lap = 0; this.distance = 0;
    this.remoteCars = new Map();
    this.buildWorld();
    this.playerCar = this.makeCar(selectedColor);
    this.scene.add(this.playerCar);
    this.resize();
    window.addEventListener('resize', () => this.resize());
    window.addEventListener('keydown', e => { if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key)) e.preventDefault(); this.keys.add(e.key.toLowerCase()); });
    window.addEventListener('keyup', e => this.keys.delete(e.key.toLowerCase()));
    this.animate();
  }
  buildWorld() {
    this.scene.add(new THREE.HemisphereLight(0xdff2ff, 0x536b45, 2.1));
    const sun = new THREE.DirectionalLight(0xfff0d4, 3.0);
    sun.position.set(-35, 55, 20); sun.castShadow = true;
    sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.left=-80; sun.shadow.camera.right=80; sun.shadow.camera.top=80; sun.shadow.camera.bottom=-80;
    this.scene.add(sun);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(260,260), new THREE.MeshStandardMaterial({color:0x6caa69, roughness:1}));
    ground.rotation.x=-Math.PI/2; ground.position.y=-0.15; ground.receiveShadow=true; this.scene.add(ground);
    // Rounded rectangular circuit made from concentric curves.
    const points = [];
    const rx=39, rz=25, corner=10;
    const centers=[ [rx-corner,rz-corner,0],[-rx+corner,rz-corner,Math.PI/2],[-rx+corner,-rz+corner,Math.PI],[rx-corner,-rz+corner,Math.PI*1.5] ];
    // Use an ellipse-like smooth loop for the road.
    const curve = new THREE.CatmullRomCurve3(Array.from({length:100},(_,i)=>{
      const a=i/100*Math.PI*2;
      return new THREE.Vector3(Math.cos(a)*rx,0,Math.sin(a)*rz);
    }), true, 'catmullrom', 0.18);
    const roadPts=curve.getPoints(220);
    const roadGeo=new THREE.BufferGeometry();
    const verts=[], indices=[];
    for(let i=0;i<roadPts.length;i++){
      const p=roadPts[i], tangent=curve.getTangent(i/220);
      const normal=new THREE.Vector3(-tangent.z,0,tangent.x).normalize();
      for(const side of [-1,1]){
        const v=p.clone().addScaledVector(normal,side*7.3);
        verts.push(v.x,0.02,v.z);
      }
      if(i<roadPts.length-1){const a=i*2;indices.push(a,a+1,a+2,a+1,a+3,a+2);}
    }
    roadGeo.setAttribute('position',new THREE.Float32BufferAttribute(verts,3)); roadGeo.setIndex(indices); roadGeo.computeVertexNormals();
    const road=new THREE.Mesh(roadGeo,new THREE.MeshStandardMaterial({color:0x343b46,roughness:0.94,side:THREE.DoubleSide}));
    road.receiveShadow=true; this.scene.add(road);
    const lineMat=new THREE.MeshStandardMaterial({color:0xf4f0d8});
    const curbMat=new THREE.MeshStandardMaterial({color:0xe74c56});
    for(let i=0;i<roadPts.length;i+=4){
      const p=roadPts[i], t=curve.getTangent(i/220), n=new THREE.Vector3(-t.z,0,t.x).normalize();
      for(const side of [-1,1]){
        const pos=p.clone().addScaledVector(n,side*7.55);
        const curb=new THREE.Mesh(new THREE.BoxGeometry(1.25,0.22,0.65),curbMat);
        curb.position.set(pos.x,0.12,pos.z); curb.rotation.y=Math.atan2(t.x,t.z); this.scene.add(curb);
      }
    }
    // Center dashed markings.
    for(let i=0;i<roadPts.length;i+=12){
      const p=roadPts[i], t=curve.getTangent(i/220);
      const dash=new THREE.Mesh(new THREE.BoxGeometry(2.0,0.035,0.12),lineMat);
      dash.position.set(p.x,0.055,p.z); dash.rotation.y=Math.atan2(t.x,t.z); this.scene.add(dash);
    }
    // Start/finish stripe across track.
    const start=new THREE.Group();
    for(let x=-7;x<8;x+=1){
      for(let z=0;z<2;z++){
        const tile=new THREE.Mesh(new THREE.BoxGeometry(1,0.05,0.75),new THREE.MeshStandardMaterial({color:(x+z)%2===0?0xffffff:0x171a22}));
        tile.position.set(x,0.08,-0.1+z*0.75); start.add(tile);
      }
    }
    start.position.set(0,0,25); start.rotation.y=Math.PI/2; this.scene.add(start);
    // Trees and decorative rocks around the circuit.
    const trunkMat=new THREE.MeshStandardMaterial({color:0x76503a});
    const leafMats=[0x2d7950,0x438c55,0x5a9d60].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1}));
    for(let i=0;i<46;i++){
      const a=i/46*Math.PI*2;
      const rX=53+Math.sin(i*4)*7, rZ=39+Math.cos(i*3)*6;
      const x=Math.cos(a)*rX,z=Math.sin(a)*rZ;
      const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.25,.38,2.3,7),trunkMat);
      trunk.position.set(x,1.0,z); trunk.castShadow=true; this.scene.add(trunk);
      const crown=new THREE.Mesh(new THREE.ConeGeometry(2.0,5.5,7),leafMats[i%3]);
      crown.position.set(x,4.3,z); crown.castShadow=true; this.scene.add(crown);
    }
    // Distant hills.
    for(let i=0;i<18;i++){
      const a=i/18*Math.PI*2, x=Math.cos(a)*95,z=Math.sin(a)*82;
      const hill=new THREE.Mesh(new THREE.ConeGeometry(13+(i%4)*3,18+(i%3)*5,7),new THREE.MeshStandardMaterial({color:0x729a75}));
      hill.position.set(x,5,z); hill.scale.z=1.6; this.scene.add(hill);
    }
    this.trackCurve=curve;
  }
  makeCar(color) {
    const group=new THREE.Group();
    const bodyMat=new THREE.MeshStandardMaterial({color,metalness:.28,roughness:.32});
    const dark=new THREE.MeshStandardMaterial({color:0x18202a,roughness:.7});
    const glass=new THREE.MeshStandardMaterial({color:0x9ed9e8,metalness:.2,roughness:.15});
    const body=new THREE.Mesh(new THREE.BoxGeometry(2.0,.65,3.7),bodyMat);
    body.position.y=.75; body.castShadow=true; group.add(body);
    const hood=new THREE.Mesh(new THREE.BoxGeometry(1.8,.25,1.15),bodyMat); hood.position.set(0,1.08,-1.05); group.add(hood);
    const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.48,.72,1.65),glass); cabin.position.set(0,1.32,.35); cabin.castShadow=true; group.add(cabin);
    const roof=new THREE.Mesh(new THREE.BoxGeometry(1.5,.12,1.55),bodyMat); roof.position.set(0,1.72,.35); group.add(roof);
    for(const x of [-1,1]) for(const z of [-1.2,1.2]){
      const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.43,.43,.28,16),dark);
      wheel.rotation.z=Math.PI/2; wheel.position.set(x*1.02,.48,z); wheel.castShadow=true; group.add(wheel);
    }
    for(const x of [-.62,.62]){
      const lamp=new THREE.Mesh(new THREE.BoxGeometry(.42,.18,.08),new THREE.MeshStandardMaterial({color:0xfff4c7,emissive:0x665522}));
      lamp.position.set(x,.86,-1.88); group.add(lamp);
    }
    group.position.set(0,0,25);
    return group;
  }
  setPlayerColor(color) {
    selectedColor=color;
    this.playerCar.traverse(o=>{if(o.isMesh && o.material?.color && (o.geometry?.type==='BoxGeometry')) {
      if (o.position.y>.6 && o.material.color.getHex()!==0x9ed9e8) o.material.color.setHex(color);
    }});
  }
  updateRemote(data) {
    let car=this.remoteCars.get(data.id);
    if(!car){car=this.makeCar(0x32c7ff); this.remoteCars.set(data.id,car); this.scene.add(car);}
    car.position.set(data.x,0,data.z); car.rotation.y=data.rotation;
  }
  start(practice) {
    this.running=true; this.practice=practice; this.speed=0; this.lap=0; this.distance=0;
    this.playerCar.position.set(0,0,25); this.playerCar.rotation.y=Math.PI/2; this.lastTrackAngle=Math.PI/2;
  }
  stop(){this.running=false; this.speed=0;}
  resize() {
    const w=this.container.clientWidth||800,h=this.container.clientHeight||500;
    this.camera.aspect=w/h; this.camera.updateProjectionMatrix(); this.renderer.setSize(w,h);
  }
  animate() {
    requestAnimationFrame(()=>this.animate());
    const dt=Math.min(this.clock.getDelta(),.04);
    if(this.running) this.update(dt);
    this.renderer.render(this.scene,this.camera);
  }
  update(dt) {
    const forward=this.keys.has('w')||this.keys.has('arrowup');
    const backward=this.keys.has('s')||this.keys.has('arrowdown');
    const left=this.keys.has('a')||this.keys.has('arrowleft');
    const right=this.keys.has('d')||this.keys.has('arrowright');
    const boost=this.keys.has('shift');
    if(forward) this.speed=Math.min(this.speed+(boost?30:19)*dt,boost?42:30);
    else if(backward) this.speed=Math.max(this.speed-30*dt,-9);
    else this.speed*=Math.pow(.965,dt*60);
    const steer=(right?1:0)-(left?1:0);
    if(Math.abs(this.speed)>.5) this.playerCar.rotation.y += steer*dt*(1.9+Math.abs(this.speed)*.045)*Math.sign(this.speed);
    const direction=new THREE.Vector3(-Math.sin(this.playerCar.rotation.y),0,-Math.cos(this.playerCar.rotation.y));
    this.playerCar.position.addScaledVector(direction,this.speed*dt);
    // Keep car within the broad play area.
    this.playerCar.position.x=THREE.MathUtils.clamp(this.playerCar.position.x,-57,57);
    this.playerCar.position.z=THREE.MathUtils.clamp(this.playerCar.position.z,-43,43);
    const trackAngle=Math.atan2(this.playerCar.position.z/25,this.playerCar.position.x/39);
    const radial=Math.sqrt((this.playerCar.position.x/39)**2+(this.playerCar.position.z/25)**2);
    if(this.lastTrackAngle>5.2 && trackAngle<1.0 && radial>0.78 && radial<1.22){
      this.lap++;
      if(this.lap>=3){
        this.lap=3; this.speed=0; this.running=false;
        toast('🏁 결승선 통과! 레이스 완주!');
        if(!this.practice && roomCode && socket.connected){
          socket.emit('player:state',{x:this.playerCar.position.x,z:this.playerCar.position.z,rotation:this.playerCar.rotation.y,lap:this.lap,finished:true});
        }
      }
    }
    this.lastTrackAngle=trackAngle;
    const target=this.playerCar.position.clone().add(new THREE.Vector3(0,8,14).applyAxisAngle(new THREE.Vector3(0,1,0),this.playerCar.rotation.y));
    this.camera.position.lerp(target,1-Math.pow(.001,dt));
    this.camera.lookAt(this.playerCar.position.clone().add(new THREE.Vector3(0,1,0)));
    $('speedText').textContent=Math.round(Math.abs(this.speed)*5.2);
    $('lapText').textContent=`${Math.min(this.lap+1,3)} / 3`;
    if(!this.practice && roomCode && socket.connected && Math.random()<dt*12) {
      socket.emit('player:state',{x:this.playerCar.position.x,z:this.playerCar.position.z,rotation:this.playerCar.rotation.y,lap:this.lap,finished:false});
    }
  }
}
const game = new RacingGame();
