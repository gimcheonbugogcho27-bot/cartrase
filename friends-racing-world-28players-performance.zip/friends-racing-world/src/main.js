import * as THREE from 'three';
import { io } from 'socket.io-client';
import './style.css';

const app = document.querySelector('#app');
app.innerHTML = `
  <div class="shell">
    <header class="topbar">
      <div class="brand"><span class="brand-mark">FR</span><span>FRIENDS <b>RACING WORLD</b></span></div>
      <div class="top-status"><span class="live-dot"></span><span id="connectionText">서버 연결 준비 중</span></div>
    </header>
    <main class="layout">
      <section class="game-panel">
        <div class="scene-wrap">
          <div id="scene"></div>
          <div class="scene-vignette"></div>
          <div class="track-label"><span class="tiny-tag">TRACK 01</span><b>NEON GRAND TOUR</b><small>롱코스 어드벤처 · 3 LAPS</small></div>
          <div id="countdown" class="countdown hidden">3</div>
          <div id="hud" class="hud hidden">
            <div class="hud-card"><small>LAP</small><b id="lapText">1 / 3</b></div>
            <div class="hud-card"><small>POSITION</small><b id="positionText">1ST</b></div>
            <div class="hud-card speed"><small>SPEED</small><b><span id="speedText">0</span><i> KM/H</i></b></div>
          </div>
          <div class="scene-bottom"><span>WASD / 방향키로 운전</span><span>회전 장애물 주의 · 초록 부스터 통과</div>
        </div>
        <div class="below-scene">
          <div><span class="eyebrow">RACE CONTROL</span><h2>트랙에 올라갈 준비가 됐나요?</h2><p>연습 주행은 혼자서도 바로 시작할 수 있어요.</p></div>
          <div class="control-hint"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd><span>운전</span></div>
        </div>
      </section>
      <aside class="side-panel">
        <section class="side-section profile">
          <div class="section-heading"><div><span class="eyebrow">YOUR DRIVER</span><h2>레이서 설정</h2></div><span class="avatar">🏎️</span></div>
          <label class="field-label" for="playerName">닉네임</label>
          <input id="playerName" maxlength="12" value="레이서" placeholder="닉네임 입력" />
          <label class="field-label">자동차 색상</label>
          <div class="colors">
            <button class="color active" data-color="#ff4d5e" style="--car:#ff4d5e" aria-label="빨강"></button>
            <button class="color" data-color="#32c7ff" style="--car:#32c7ff" aria-label="파랑"></button>
            <button class="color" data-color="#ffd34e" style="--car:#ffd34e" aria-label="노랑"></button>
            <button class="color" data-color="#8b6cff" style="--car:#8b6cff" aria-label="보라"></button>
            <button class="color" data-color="#45d69a" style="--car:#45d69a" aria-label="초록"></button>
            <button class="color" data-color="#f4f6fb" style="--car:#f4f6fb" aria-label="흰색"></button>
          </div>
        </section>
        <section class="side-section room-section">
          <div class="section-heading"><div><span class="eyebrow">MULTIPLAYER</span><h2>온라인 레이스</h2></div><span class="capacity">0 / 28</span></div>
          <button id="createRoom" class="primary-btn"><span>＋</span> 레이싱 방 만들기</button>
          <div class="join-row"><input id="roomCode" maxlength="5" placeholder="초대 코드 5자리" /><button id="joinRoom" class="secondary-btn">참가</button></div>
          <div id="roomInfo" class="room-info hidden">
            <div class="room-code-line"><span>방 초대 코드</span><button id="copyCode" class="copy-btn">복사</button></div>
            <strong id="roomCodeText">-----</strong>
            <div id="playerList" class="player-list"></div>
            <div class="room-actions"><button id="readyBtn" class="secondary-btn">준비 완료</button><button id="startRace" class="primary-btn">경기 시작</button></div>
          </div>
          <div id="roomMessage" class="room-message">방을 만들거나 친구의 초대 코드를 입력하세요.</div>
        </section>
        <section class="side-section practice-section">
          <div class="section-heading"><div><span class="eyebrow">QUICK PLAY</span><h2>바로 플레이</h2></div></div>
          <button id="practiceBtn" class="practice-btn"><span class="play-icon">▶</span><span><b>혼자 연습하기</b><small>혼자서 트랙을 달려보세요</small></span><span class="arrow">→</span></button>
          <button id="leaveBtn" class="text-btn hidden">방 나가기</button>
        </section>
        <section class="side-section leaderboard">
          <div class="section-heading"><div><span class="eyebrow">RACE INFO</span><h2>레이스 정보</h2></div></div>
          <div class="info-row"><span>현재 트랙</span><b>네온 그랜드 투어</b></div>
          <div class="info-row"><span>최대 참가 인원</span><b>28명</b></div>
          <div class="info-row"><span>완주 랩</span><b>3바퀴</b></div>
        </section>
        <footer>FRIENDS RACING WORLD <span>v1.0.0</span></footer>
      </aside>
    </main>
    <div id="toast" class="toast"></div>
    <div class="mobile-controls" aria-label="모바일 운전 조작">
      <div class="touch-steering">
        <button class="touch-btn steer" data-key="arrowleft" aria-label="왼쪽">◀</button>
        <button class="touch-btn steer" data-key="arrowright" aria-label="오른쪽">▶</button>
      </div>
      <div class="touch-pedals">
        <button class="touch-btn brake" data-key="arrowdown" aria-label="브레이크">브레이크</button>
        <button class="touch-btn accelerate" data-key="arrowup" aria-label="가속">가속 ▲</button>
        <button class="touch-btn boost" data-key="shift" aria-label="부스트">BOOST</button>
      </div>
    </div>
  </div>
`;

const $ = id => document.getElementById(id);
const toast = message => {
  $('toast').textContent = message;
  $('toast').classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => $('toast').classList.remove('show'), 2600);
};
const serverUrl = import.meta.env.VITE_GAME_SERVER_URL || undefined;
const socket = io(serverUrl, { autoConnect: true, reconnection: true });
let connected = false, roomCode = null, isHost = false, isReady = false;
let roomPlayers = [], raceMode = 'idle', countdownTimer = null;
let selectedColor = 0xff4d5e;
const colorValue = hex => parseInt(hex.replace('#',''), 16);
socket.on('connect', () => { connected = true; $('connectionText').textContent = '온라인 서버 연결됨'; });
socket.on('disconnect', () => { connected = false; $('connectionText').textContent = '서버 연결 끊김 · 재연결 중'; });
socket.on('connect_error', () => { $('connectionText').textContent = '서버 연결 대기 중'; });
socket.on('room:update', data => {
  roomCode = data.code; roomPlayers = data.players; isHost = data.hostId === socket.id;
  // Host identity is supplied separately on room creation/join; preserve it.
  renderRoom(data);
});
socket.on('players:states', states => states.forEach(s => { if (s.id !== socket.id) game.updateRemote(s); }));
socket.on('race:countdown', ({seconds}) => startCountdown(seconds));
socket.on('race:finished', () => { raceMode = 'finished'; $('roomMessage').textContent = '🏁 모든 레이서가 결승선을 통과했습니다!'; });
function renderRoom(data) {
  $('roomInfo').classList.remove('hidden');
  $('roomCodeText').textContent = data.code;
  $('roomCode').value = data.code;
  $('roomMessage').textContent = data.state === 'racing' ? '레이스 진행 중!' : '친구들이 입장하기를 기다리고 있어요.';
  document.querySelector('.capacity').textContent = `${data.players.length} / 28`;
  $('playerList').innerHTML = data.players.map((p,i) => `<div class="player-row"><span class="player-dot" style="--car:#${Number(p.color).toString(16).padStart(6,'0')}"></span><span>${escapeHtml(p.name)} ${p.id === socket.id ? '<em>(나)</em>' : ''}</span><small>${p.ready ? '준비 완료' : '대기 중'}</small></div>`).join('');
  $('startRace').classList.toggle('hidden', !isHost);
  $('readyBtn').classList.toggle('hidden', isHost || data.state !== 'waiting');
  $('readyBtn').textContent = isReady ? '준비 취소' : '준비 완료';
  $('startRace').disabled = data.players.length < 1;
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

$('createRoom').onclick = () => {
  if (!connected) return toast('온라인 서버에 연결 중입니다. 잠시 후 다시 시도하세요.');
  socket.emit('room:create', { name: $('playerName').value, color: selectedColor }, result => {
    if (!result.ok) return toast(result.error);
    roomCode = result.code; isHost = true; isReady = true;
    toast(`방이 만들어졌어요! 초대 코드: ${result.code}`);
  });
};
$('joinRoom').onclick = () => {
  if (!connected) return toast('온라인 서버에 연결되지 않았습니다.');
  const code = $('roomCode').value.trim().toUpperCase();
  if (code.length !== 5) return toast('초대 코드 5자리를 입력하세요.');
  socket.emit('room:join', { code, name: $('playerName').value, color: selectedColor }, result => {
    if (!result.ok) return toast(result.error);
    roomCode = result.code; isHost = false; isReady = false;
    toast('레이싱 방에 참가했습니다!');
  });
};
$('readyBtn').onclick = () => {
  isReady = !isReady;
  socket.emit('player:ready', isReady);
  $('readyBtn').textContent = isReady ? '준비 취소' : '준비 완료';
};
$('startRace').onclick = () => {
  if (!isHost) return;
  socket.emit('race:start');
};
$('copyCode').onclick = async () => {
  try { await navigator.clipboard.writeText(roomCode || ''); toast('초대 코드를 복사했습니다!'); }
  catch { toast(`초대 코드: ${roomCode}`); }
};
$('leaveBtn').onclick = () => { socket.disconnect(); socket.connect(); roomCode = null; $('roomInfo').classList.add('hidden'); $('leaveBtn').classList.add('hidden'); toast('방에서 나왔습니다.'); };
$('practiceBtn').onclick = () => {
  raceMode = 'practice'; game.start(true); $('hud').classList.remove('hidden');
  $('roomMessage').textContent = '연습 주행 중입니다. ESC를 눌러 메뉴로 돌아오세요.';
  toast('연습 주행을 시작합니다!');
};
document.querySelectorAll('.color').forEach(btn => btn.onclick = () => {
  document.querySelectorAll('.color').forEach(b => b.classList.remove('active'));
  btn.classList.add('active'); selectedColor = colorValue(btn.dataset.color); game.setPlayerColor(selectedColor);
});
function startCountdown(seconds) {
  $('countdown').classList.remove('hidden');
  let n = seconds;
  $('countdown').textContent = n;
  clearInterval(countdownTimer);
  countdownTimer = setInterval(() => {
    n--;
    if (n <= 0) {
      clearInterval(countdownTimer);
      $('countdown').textContent = 'GO!';
      setTimeout(() => $('countdown').classList.add('hidden'), 700);
      raceMode = 'online'; game.start(false); $('hud').classList.remove('hidden');
      $('leaveBtn').classList.remove('hidden');
    } else $('countdown').textContent = n;
  }, 1000);
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && raceMode !== 'idle') {
    raceMode = 'idle'; game.stop(); $('hud').classList.add('hidden'); toast('메뉴로 돌아왔습니다.');
  }
});
// Touch controls: keep keys lowercase to match the keyboard input system.
document.querySelectorAll('.mobile-controls button').forEach(btn => {
  const key = btn.dataset.key;
  const release = e => {
    if (e) e.preventDefault();
    game.keys.delete(key);
    btn.classList.remove('pressed');
  };
  btn.addEventListener('pointerdown', e => {
    e.preventDefault();
    game.keys.add(key);
    btn.classList.add('pressed');
    try { btn.setPointerCapture(e.pointerId); } catch {}
  });
  ['pointerup','pointercancel','lostpointercapture','pointerleave'].forEach(ev => {
    btn.addEventListener(ev, release);
  });
  btn.addEventListener('contextmenu', e => e.preventDefault());
});

class RacingGame {
  constructor() {
    this.container = $('scene');
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x9ac8e4);
    this.scene.fog = new THREE.Fog(0x9ac8e4, 65, 190);
    this.camera = new THREE.PerspectiveCamera(55, 1, 0.1, 500);
    this.camera.position.set(0, 13, 22);
    const mobile = matchMedia('(max-width: 800px), (pointer: coarse)').matches;
    this.mobile = mobile;
    this.renderer = new THREE.WebGLRenderer({ antialias: !mobile, powerPreference: 'high-performance', alpha: false });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, mobile ? 1 : 1.35));
    // Real-time shadows and filmic tone mapping are expensive on phones.
    this.renderer.shadowMap.enabled = false;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.container.appendChild(this.renderer.domElement);
    this.clock = new THREE.Clock();
    this.keys = new Set();
    this.running = false;
    this.speed = 0; this.rotation = 0; this.lap = 0; this.distance = 0;
    this.remoteCars = new Map();
    this.buildWorld();
    this.playerCar = this.makeCar(selectedColor);
    this.scene.add(this.playerCar);
    this.resize();
    window.addEventListener('resize', () => this.resize());
    window.addEventListener('keydown', e => { if (['ArrowUp','ArrowDown','ArrowLeft','ArrowRight',' '].includes(e.key)) e.preventDefault(); this.keys.add(e.key.toLowerCase()); });
    window.addEventListener('keyup', e => this.keys.delete(e.key.toLowerCase()));
    this.animate();
  }
  buildWorld() {
    this.scene.add(new THREE.HemisphereLight(0xdff5ff, 0x26334b, 2.0));
    const sun = new THREE.DirectionalLight(0xffe2b0, 3.2);
    sun.position.set(-90, 130, 70); sun.castShadow = false; this.scene.add(sun);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(900,700), new THREE.MeshStandardMaterial({color:0x172b35,roughness:1}));
    ground.rotation.x=-Math.PI/2; ground.position.y=-1.2; ground.receiveShadow=true; this.scene.add(ground);
    // A long, closed grand-prix route with multiple hairpins and sweeping S-bends.
    const route = [
      [-12,0,145],[35,0,142],[95,0,128],[145,0,95],[160,0,45],[145,0,-8],[105,0,-42],[45,0,-52],
      [-18,0,-40],[-82,0,-18],[-145,0,-30],[-190,0,-72],[-195,0,-125],[-160,0,-166],[-95,0,-178],
      [-35,0,-160],[18,0,-130],[65,0,-145],[95,0,-195],[75,0,-245],[25,0,-265],[-35,0,-250],
      [-85,0,-215],[-145,0,-220],[-205,0,-190],[-235,0,-135],[-230,0,-65],[-205,0,5],[-165,0,65],
      [-110,0,112],[-55,0,140]
    ].map(p=>new THREE.Vector3(...p));
    const curve = new THREE.CatmullRomCurve3(route,true,'catmullrom',0.16);
    this.trackCurve=curve;
    const segments=1500, roadPts=curve.getPoints(segments);
    const verts=[], indices=[];
    for(let i=0;i<roadPts.length;i++){
      const p=roadPts[i],t=curve.getTangent(i/segments),n=new THREE.Vector3(-t.z,0,t.x).normalize();
      const crown=0.18*Math.sin(i/segments*Math.PI*16);
      for(const side of [-1,1]){const v=p.clone().addScaledVector(n,side*8.5);verts.push(v.x,p.y+crown,v.z);}
      if(i<roadPts.length-1){const a=i*2;indices.push(a,a+1,a+2,a+1,a+3,a+2);}
    }
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(verts,3));geo.setIndex(indices);geo.computeVertexNormals();
    const road=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:0x252d3b,roughness:.82,metalness:.12,side:THREE.DoubleSide}));road.receiveShadow=true;this.scene.add(road);
    const edgeMat=new THREE.MeshStandardMaterial({color:0x00d9ff,emissive:0x007caa,emissiveIntensity:1.7});
    const redMat=new THREE.MeshStandardMaterial({color:0xff536f,emissive:0x9b1238,emissiveIntensity:1.2});
    const railMat=new THREE.MeshStandardMaterial({color:0x66788d,metalness:.65,roughness:.35});
    for(let i=0;i<roadPts.length-1;i+=15){
      const p=roadPts[i],t=curve.getTangent(i/segments),n=new THREE.Vector3(-t.z,0,t.x).normalize();
      for(const side of [-1,1]){
        const q=p.clone().addScaledVector(n,side*8.7);
        const strip=new THREE.Mesh(new THREE.BoxGeometry(2.1,.12,.22),edgeMat);strip.position.set(q.x,.2,q.z);strip.rotation.y=Math.atan2(t.x,t.z);this.scene.add(strip);
        if(i%45===0){const barrier=new THREE.Mesh(new THREE.BoxGeometry(2.4,.8,.35),railMat);barrier.position.set(q.x,.55,q.z);barrier.rotation.y=Math.atan2(t.x,t.z);barrier.castShadow=true;this.scene.add(barrier);}
      }
      if(i%54===0){const dash=new THREE.Mesh(new THREE.BoxGeometry(2.4,.035,.16),new THREE.MeshBasicMaterial({color:0xeaf5ff}));dash.position.set(p.x,.23,p.z);dash.rotation.y=Math.atan2(t.x,t.z);this.scene.add(dash);}
    }
    // Start line and illuminated checkpoint arches.
    this.startPosition=curve.getPointAt(0.015);this.startTangent=curve.getTangentAt(0.015);
    const startGroup=new THREE.Group();
    for(let x=-8;x<9;x++)for(let z=0;z<2;z++){const tile=new THREE.Mesh(new THREE.BoxGeometry(1,.08,.8),new THREE.MeshStandardMaterial({color:(x+z)%2?0x111827:0xffffff}));tile.position.set(x,.25,z*.8);startGroup.add(tile);}
    startGroup.position.copy(this.startPosition);startGroup.rotation.y=Math.atan2(this.startTangent.x,this.startTangent.z);this.scene.add(startGroup);
    this.hazards=[];this.animatedObstacles=[];
    const addArch=(t,color=0xffb347)=>{const p=curve.getPointAt(t),tan=curve.getTangentAt(t),g=new THREE.Group(),mat=new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:1.3,metalness:.3});
      const left=new THREE.Mesh(new THREE.BoxGeometry(.7,8,.7),mat),right=left.clone(),top=new THREE.Mesh(new THREE.BoxGeometry(18,.7,.7),mat);left.position.set(-8,4,0);right.position.set(8,4,0);top.position.set(0,8,0);g.add(left,right,top);g.position.copy(p);g.rotation.y=Math.atan2(tan.x,tan.z);this.scene.add(g);};
    [0.08,0.25,0.43,0.61,0.79,0.92].forEach((t,i)=>addArch(t,[0xffb347,0x5ce1ff,0xff5d9e,0x8b79ff,0x55f0b0,0xffb347][i]));
    // Rotating sweepers, swinging hammers, bumpers and glowing boost pads.
    const obstacleMat=new THREE.MeshStandardMaterial({color:0xff4f6d,emissive:0x9c1535,emissiveIntensity:1.5,metalness:.35});
    const cyanMat=new THREE.MeshStandardMaterial({color:0x39ddff,emissive:0x087fa9,emissiveIntensity:1.7});
    for(let i=0;i<12;i++){
      const t=.045+i*.078,p=curve.getPointAt(t),tan=curve.getTangentAt(t),angle=Math.atan2(tan.x,tan.z);
      if(i%3===0){
        const pivot=new THREE.Group();pivot.position.copy(p);pivot.position.y=1.35;pivot.rotation.y=angle;
        const beam=new THREE.Mesh(new THREE.BoxGeometry(15,.65,1.1),obstacleMat);beam.position.y=.4;beam.castShadow=true;pivot.add(beam);
        const hub=new THREE.Mesh(new THREE.CylinderGeometry(1.15,1.15,1.8,16),cyanMat);hub.rotation.x=Math.PI/2;hub.position.y=.4;pivot.add(hub);this.scene.add(pivot);this.animatedObstacles.push({object:pivot,kind:'spin',rate:1.15+i*.08});
        this.hazards.push({position:p.clone(),radius:6,penalty:0.55});
      } else if(i%3===1){
        const bumper=new THREE.Group();bumper.position.copy(p);bumper.position.y=1.2;
        const ball=new THREE.Mesh(new THREE.SphereGeometry(2.4,20,16),new THREE.MeshStandardMaterial({color:0xffc34f,emissive:0x8a4b00,emissiveIntensity:1.2,metalness:.3}));ball.castShadow=true;bumper.add(ball);this.scene.add(bumper);
        this.animatedObstacles.push({object:bumper,kind:'bounce',baseY:1.2,phase:i});this.hazards.push({position:p.clone(),radius:4.5,penalty:.45});
      } else {
        const pad=new THREE.Mesh(new THREE.BoxGeometry(7,.18,10),new THREE.MeshStandardMaterial({color:0x29e5a2,emissive:0x08a66c,emissiveIntensity:2.2}));pad.position.copy(p);pad.position.y=.28;pad.rotation.y=angle;this.scene.add(pad);
        this.boostPads??=[];this.boostPads.push({position:p.clone(),radius:7});
      }
    }
    // Ramps and raised-looking stunt platforms decorate key sections.
    for(let i=0;i<5;i++){
      const t=.13+i*.17,p=curve.getPointAt(t),tan=curve.getTangentAt(t),ramp=new THREE.Mesh(new THREE.BoxGeometry(12,1.1,18),new THREE.MeshStandardMaterial({color:0x465d78,metalness:.45,roughness:.4}));
      ramp.position.copy(p);ramp.position.y=.45;ramp.rotation.y=Math.atan2(tan.x,tan.z);ramp.rotation.x=-.08;ramp.castShadow=true;this.scene.add(ramp);
      const glow=new THREE.Mesh(new THREE.BoxGeometry(12,.15,18),cyanMat);glow.position.copy(ramp.position);glow.position.y=1.05;glow.rotation.copy(ramp.rotation);this.scene.add(glow);
    }
    // Huge themed scenery around the full-length route.
    const mountainMat=[0x263d57,0x344c65,0x294c4c].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:1}));
    for(let i=0;i<28;i++){
      const a=i/28*Math.PI*2,r=260+(i%5)*15,x=Math.cos(a)*r,z=Math.sin(a)*r;
      const hill=new THREE.Mesh(new THREE.ConeGeometry(15+(i%6)*5,35+(i%7)*8,7),mountainMat[i%3]);hill.position.set(x,10,z);hill.scale.z=1.4;hill.castShadow=true;this.scene.add(hill);
    }
    const towerMat=new THREE.MeshStandardMaterial({color:0x182c48,metalness:.55,roughness:.4});
    for(let i=0;i<14;i++){
      const a=i*2.399,r=135+(i%7)*18,x=Math.cos(a)*r,z=Math.sin(a)*r,h=12+(i%5)*7;
      const tower=new THREE.Mesh(new THREE.BoxGeometry(5,h,5),towerMat);tower.position.set(x,h/2,z);this.scene.add(tower);
      
    }
    this.elapsed=0;
  }
  makeCar(color) {
    const group=new THREE.Group();
    const bodyMat=new THREE.MeshStandardMaterial({color,metalness:.28,roughness:.32});
    const dark=new THREE.MeshStandardMaterial({color:0x18202a,roughness:.7});
    const glass=new THREE.MeshStandardMaterial({color:0x9ed9e8,metalness:.2,roughness:.15});
    const body=new THREE.Mesh(new THREE.BoxGeometry(2.0,.65,3.7),bodyMat);
    body.position.y=.75; body.castShadow=true; group.add(body);
    const hood=new THREE.Mesh(new THREE.BoxGeometry(1.8,.25,1.15),bodyMat); hood.position.set(0,1.08,-1.05); group.add(hood);
    const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.48,.72,1.65),glass); cabin.position.set(0,1.32,.35); cabin.castShadow=true; group.add(cabin);
    const roof=new THREE.Mesh(new THREE.BoxGeometry(1.5,.12,1.55),bodyMat); roof.position.set(0,1.72,.35); group.add(roof);
    for(const x of [-1,1]) for(const z of [-1.2,1.2]){
      const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.43,.43,.28,16),dark);
      wheel.rotation.z=Math.PI/2; wheel.position.set(x*1.02,.48,z); wheel.castShadow=true; group.add(wheel);
    }
    for(const x of [-.62,.62]){
      const lamp=new THREE.Mesh(new THREE.BoxGeometry(.42,.18,.08),new THREE.MeshStandardMaterial({color:0xfff4c7,emissive:0x665522}));
      lamp.position.set(x,.86,-1.88); group.add(lamp);
    }
    group.position.set(this.startPosition?.x ?? 0,0,this.startPosition?.z ?? 25);
    return group;
  }
  setPlayerColor(color) {
    selectedColor=color;
    this.playerCar.traverse(o=>{if(o.isMesh && o.material?.color && (o.geometry?.type==='BoxGeometry')) {
      if (o.position.y>.6 && o.material.color.getHex()!==0x9ed9e8) o.material.color.setHex(color);
    }});
  }
  updateRemote(data) {
    let car=this.remoteCars.get(data.id);
    if(!car){car=this.makeCar(0x32c7ff); this.remoteCars.set(data.id,car); this.scene.add(car);}
    car.position.set(data.x,0,data.z); car.rotation.y=data.rotation;
  }
  start(practice) {
    this.running=true; this.practice=practice; this.speed=0; this.lap=0; this.distance=0;
    this.playerCar.position.copy(this.startPosition || new THREE.Vector3(0,0,25)); this.playerCar.rotation.y=Math.atan2(-(this.startTangent?.x || 1),-(this.startTangent?.z || 0)); this.lastProgress=0.015;
  }
  stop(){this.running=false; this.speed=0;}
  resize() {
    const w=this.container.clientWidth||800,h=this.container.clientHeight||500;
    this.camera.aspect=w/h; this.camera.updateProjectionMatrix(); this.renderer.setSize(w,h);
  }
  animate(now=0) {
    requestAnimationFrame(t=>this.animate(t));
    const frameInterval=this.mobile ? 1000/30 : 1000/50;
    if(now-this.lastFrame<frameInterval) return;
    this.lastFrame=now;
    const dt=Math.min(this.clock.getDelta(),.05);
    if(this.running) this.update(dt);
    this.renderer.render(this.scene,this.camera);
  }
  update(dt) {
    const forward=this.keys.has('w')||this.keys.has('arrowup');
    const backward=this.keys.has('s')||this.keys.has('arrowdown');
    const left=this.keys.has('a')||this.keys.has('arrowleft');
    const right=this.keys.has('d')||this.keys.has('arrowright');
    const boost=this.keys.has('shift');
    if(forward) this.speed=Math.min(this.speed+(boost?30:19)*dt,boost?42:30);
    else if(backward) this.speed=Math.max(this.speed-30*dt,-9);
    else this.speed*=Math.pow(.965,dt*60);
    const steer=(right?1:0)-(left?1:0);
    if(Math.abs(this.speed)>.5) this.playerCar.rotation.y += steer*dt*(1.9+Math.abs(this.speed)*.045)*Math.sign(this.speed);
    const direction=new THREE.Vector3(-Math.sin(this.playerCar.rotation.y),0,-Math.cos(this.playerCar.rotation.y));
    this.playerCar.position.addScaledVector(direction,this.speed*dt);
    // Keep car within the broad play area.
    this.playerCar.position.x=THREE.MathUtils.clamp(this.playerCar.position.x,-255,255);
    this.playerCar.position.z=THREE.MathUtils.clamp(this.playerCar.position.z,-285,175);
    // Estimate progress along the long circuit and count a lap when crossing its start.
    let nearestT=this.lastProgress ?? 0, nearestD=Infinity;
    for(let i=0;i<=90;i++){const t=i/90,p=this.trackCurve.getPointAt(t),d=p.distanceToSquared(this.playerCar.position);if(d<nearestD){nearestD=d;nearestT=t;}}
    if(this.lastProgress>.88 && nearestT<.12 && nearestD<260){
      this.lap++;
      if(this.lap>=3){this.lap=3;this.speed=0;this.running=false;toast('🏁 결승선 통과! 레이스 완주!');if(!this.practice&&roomCode&&socket.connected)socket.emit('player:state',{x:this.playerCar.position.x,z:this.playerCar.position.z,rotation:this.playerCar.rotation.y,lap:this.lap,finished:true});}
    }
    this.lastProgress=nearestT;
    this.elapsed=(this.elapsed||0)+dt;
    for(const o of this.animatedObstacles||[]){if(o.kind==='spin')o.object.rotation.y+=dt*o.rate;else o.object.position.y=o.baseY+Math.sin(this.elapsed*2.1+o.phase)*1.3;}
    for(const h of this.hazards||[]){if(this.playerCar.position.distanceTo(h.position)<h.radius){this.speed*=Math.pow(h.penalty,dt*5);}}
    for(const b of this.boostPads||[]){if(this.playerCar.position.distanceTo(b.position)<b.radius)this.speed=Math.min(44,this.speed+18*dt);}
    const target=this.playerCar.position.clone().add(new THREE.Vector3(0,11,19).applyAxisAngle(new THREE.Vector3(0,1,0),this.playerCar.rotation.y));
    this.camera.position.lerp(target,1-Math.pow(.001,dt));
    this.camera.lookAt(this.playerCar.position.clone().add(new THREE.Vector3(0,1,0)));
    $('speedText').textContent=Math.round(Math.abs(this.speed)*5.2);
    $('lapText').textContent=`${Math.min(this.lap+1,3)} / 3`;
    if(!this.practice && roomCode && socket.connected && Math.random()<dt*6) {
      socket.emit('player:state',{x:this.playerCar.position.x,z:this.playerCar.position.z,rotation:this.playerCar.rotation.y,lap:this.lap,finished:false});
    }
  }
}
const game = new RacingGame();
