const { app, BrowserWindow, dialog } = require('electron');
const { spawn } = require('node:child_process');
const path = require('node:path');
const http = require('node:http');

let serverProcess;
let mainWindow;

function waitForServer(url, tries = 40) {
  return new Promise((resolve, reject) => {
    let count = 0;
    const check = () => {
      const req = http.get(url, res => {
        res.resume();
        resolve();
      });
      req.on('error', () => {
        count++;
        if (count >= tries) reject(new Error('게임 서버를 시작하지 못했습니다.'));
        else setTimeout(check, 250);
      });
    };
    check();
  });
}

async function createWindow() {
  const root = app.isPackaged ? path.join(process.resourcesPath, 'app.asar.unpacked') : path.join(__dirname, '..');
  const serverFile = path.join(root, 'server.js');
  serverProcess = spawn(process.execPath, [serverFile], {
    cwd: root,
    env: { ...process.env, PORT: '3000', ELECTRON_RUN_AS_NODE: '1' },
    stdio: 'ignore',
    windowsHide: true
  });
  try {
    await waitForServer('http://127.0.0.1:3000/health');
    mainWindow = new BrowserWindow({
      width: 1440, height: 900, minWidth: 980, minHeight: 650,
      backgroundColor: '#08111f',
      autoHideMenuBar: true,
      webPreferences: { contextIsolation: true, nodeIntegration: false }
    });
    await mainWindow.loadURL('http://127.0.0.1:3000');
  } catch (error) {
    dialog.showErrorBox('Friends Racing World', error.message);
    app.quit();
  }
}

app.whenReady().then(createWindow);
app.on('before-quit', () => { if (serverProcess) serverProcess.kill(); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
