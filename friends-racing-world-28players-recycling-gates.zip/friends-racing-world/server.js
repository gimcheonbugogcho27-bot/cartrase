import express from 'express';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: '*' },
  pingInterval: 25000,
  pingTimeout: 20000,
  maxHttpBufferSize: 1e6
});

app.use(express.static(path.join(__dirname, 'dist')));
app.get('/health', (_req, res) => res.json({ ok: true, game: 'Friends Racing World' }));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'dist', 'index.html')));

const rooms = new Map();
const MAX_PLAYERS = 28;
const cleanName = (value) => String(value || '레이서').trim().slice(0, 12) || '레이서';
const makeCode = () => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
};

function roomSnapshot(room) {
  return {
    code: room.code,
    hostId: room.hostId,
    state: room.state,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, color: p.color, ready: p.ready,
      x: p.x, z: p.z, rotation: p.rotation, lap: p.lap, finished: p.finished
    }))
  };
}
function emitRoom(room) {
  io.to(room.code).emit('room:update', roomSnapshot(room));
}
function removeFromRoom(socket) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  if (!room) return;
  room.players.delete(socket.id);
  socket.leave(code);
  socket.data.roomCode = null;
  if (room.players.size === 0) {
    rooms.delete(code);
  } else {
    if (room.hostId === socket.id) room.hostId = room.players.keys().next().value;
    if (room.players.size < 2 && room.state === 'racing') room.state = 'waiting';
    emitRoom(room);
  }
}

io.on('connection', socket => {
  socket.emit('server:ready', { maxPlayers: MAX_PLAYERS });

  socket.on('room:create', ({ name, color } = {}, callback = () => {}) => {
    removeFromRoom(socket);
    let code = makeCode();
    while (rooms.has(code)) code = makeCode();
    const room = { code, hostId: socket.id, state: 'waiting', players: new Map(), createdAt: Date.now() };
    rooms.set(code, room);
    room.players.set(socket.id, {
      id: socket.id, name: cleanName(name), color: Number(color) || 0xff4d5e,
      ready: true, x: 0, z: 0, rotation: 0, lap: 0, finished: false
    });
    socket.join(code);
    socket.data.roomCode = code;
    callback({ ok: true, code, isHost: true });
    emitRoom(room);
  });

  socket.on('room:join', ({ code, name, color } = {}, callback = () => {}) => {
    const roomCode = String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 5);
    const room = rooms.get(roomCode);
    if (!room) return callback({ ok: false, error: '방을 찾을 수 없습니다.' });
    if (room.state === 'racing') return callback({ ok: false, error: '이미 경기가 진행 중입니다.' });
    if (room.players.size >= MAX_PLAYERS) return callback({ ok: false, error: '방이 가득 찼습니다. (최대 28명)' });
    removeFromRoom(socket);
    room.players.set(socket.id, {
      id: socket.id, name: cleanName(name), color: Number(color) || 0x32c7ff,
      ready: false, x: 0, z: 0, rotation: 0, lap: 0, finished: false
    });
    socket.join(roomCode);
    socket.data.roomCode = roomCode;
    callback({ ok: true, code: roomCode, isHost: room.hostId === socket.id });
    emitRoom(room);
  });

  socket.on('player:ready', ready => {
    const room = rooms.get(socket.data.roomCode);
    const player = room?.players.get(socket.id);
    if (!player || room.state !== 'waiting') return;
    player.ready = !!ready;
    emitRoom(room);
  });

  socket.on('race:start', () => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.hostId !== socket.id || room.state !== 'waiting') return;
    if (room.players.size < 1) return;
    room.state = 'racing';
    for (const p of room.players.values()) {
      p.x = 0; p.z = 0; p.rotation = 0; p.lap = 0; p.finished = false;
    }
    io.to(room.code).emit('race:countdown', { seconds: 3 });
    emitRoom(room);
  });

  socket.on('player:state', state => {
    const room = rooms.get(socket.data.roomCode);
    const player = room?.players.get(socket.id);
    if (!player || room.state !== 'racing' || !state) return;
    const n = (v, fallback = 0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
    player.x = Math.max(-90, Math.min(90, n(state.x)));
    player.z = Math.max(-90, Math.min(90, n(state.z)));
    player.rotation = n(state.rotation);
    player.lap = Math.max(0, Math.min(3, Math.floor(n(state.lap))));
    player.finished = !!state.finished;
    socket.to(room.code).emit('players:states', [{
      id: player.id, x: player.x, z: player.z,
      rotation: player.rotation, lap: player.lap, finished: player.finished
    }]);
    if ([...room.players.values()].every(p => p.finished)) {
      room.state = 'finished';
      io.to(room.code).emit('race:finished', roomSnapshot(room));
      emitRoom(room);
    }
  });

  socket.on('race:back-to-lobby', () => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || room.hostId !== socket.id) return;
    room.state = 'waiting';
    for (const p of room.players.values()) {
      p.ready = p.id === room.hostId;
      p.lap = 0; p.finished = false; p.x = 0; p.z = 0;
    }
    emitRoom(room);
  });

  socket.on('disconnect', () => removeFromRoom(socket));
});

const port = Number(process.env.PORT || 3000);
httpServer.listen(port, '0.0.0.0', () => {
  console.log(`Friends Racing World server listening on ${port}`);
});
